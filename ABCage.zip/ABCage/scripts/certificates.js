const certifications = GLightbox({
    selector: ".certificates-lightbox"
});
