
// Слайдер со статьями
const blogSwiper = new Swiper('.blog__swiper', {
    spaceBetween: 25,
    slidesPerView: 'auto',
    autoplay: {
        pauseOnMouseEnter: true,
    },


});
